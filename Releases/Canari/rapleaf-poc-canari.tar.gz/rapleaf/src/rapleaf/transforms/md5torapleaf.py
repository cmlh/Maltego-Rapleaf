#!/usr/bin/env python

from canari.maltego.entities import Phrase
from canari.maltego.utils import debug, progress
from canari.framework import configure, ExternalCommand

__author__ = 'Christian Heinrich'
__copyright__ = 'Copyright 2012, Rapleaf Project'
__credits__ = []

__license__ = 'GPL'
__version__ = '0.1'
__maintainer__ = 'Christian Heinrich'
__email__ = 'christian.heinrich@cmlh.id.au'
__status__ = 'Development'

__all__ = [
    'dotransform',
]


@configure(
    label='To Location and Gender [Rapleaf]',
    description='Returns a location and gender entity for a particular MD5 string using Rapleaf.',
    uuids=[ 'rapleaf.v2.MD5ToLocationAndGender_Rapleaf' ],
    inputs=[ ( 'Rapleaf', Phrase ) ],
    debug=True,
    cmd=ExternalCommand('from_md5-to_rapleaf.pl', interpreter='perl')
)
def dotransform(request, response):
    pass

